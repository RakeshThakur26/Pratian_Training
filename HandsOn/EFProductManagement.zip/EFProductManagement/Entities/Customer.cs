﻿namespace EFProductManagement.Entities
{
    public class Customer : Person
    {
        public string Type { get; set; }
        public double Discount { get; set; }
        public virtual Address Address { get; set; }

    }
}
