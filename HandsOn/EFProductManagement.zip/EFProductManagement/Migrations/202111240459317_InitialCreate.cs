﻿namespace EFProductManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Catagories",
                c => new
                    {
                        CatagoryId = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 40),
                    })
                .PrimaryKey(t => t.CatagoryId);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        ProductId = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false),
                        Price = c.Int(nullable: false),
                        Description = c.String(storeType: "ntext"),
                        Brand = c.String(),
                        catagory_CatagoryId = c.Int(),
                    })
                .PrimaryKey(t => t.ProductId)
                .ForeignKey("dbo.Catagories", t => t.catagory_CatagoryId)
                .Index(t => t.catagory_CatagoryId);
            
            CreateTable(
                "dbo.People",
                c => new
                    {
                        personId = c.Int(nullable: false, identity: true),
                        FirstName = c.String(),
                        LastName = c.Int(nullable: false),
                        SupplierId = c.Int(),
                        Mobile = c.String(),
                        Email = c.String(),
                        Address_Area = c.String(),
                        Address_City = c.String(),
                        Address_Pincode = c.String(),
                        Address_Country = c.String(),
                        Type = c.String(),
                        Discount = c.Double(),
                        Address_Area1 = c.String(),
                        Address_City1 = c.String(),
                        Address_Pincode1 = c.String(),
                        Address_Country1 = c.String(),
                        Discriminator = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => t.personId);
            
            CreateTable(
                "dbo.SuppliersProducts",
                c => new
                    {
                        Suppliers_personId = c.Int(nullable: false),
                        Product_ProductId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Suppliers_personId, t.Product_ProductId })
                .ForeignKey("dbo.People", t => t.Suppliers_personId, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.Product_ProductId, cascadeDelete: true)
                .Index(t => t.Suppliers_personId)
                .Index(t => t.Product_ProductId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.SuppliersProducts", "Product_ProductId", "dbo.Products");
            DropForeignKey("dbo.SuppliersProducts", "Suppliers_personId", "dbo.People");
            DropForeignKey("dbo.Products", "catagory_CatagoryId", "dbo.Catagories");
            DropIndex("dbo.SuppliersProducts", new[] { "Product_ProductId" });
            DropIndex("dbo.SuppliersProducts", new[] { "Suppliers_personId" });
            DropIndex("dbo.Products", new[] { "catagory_CatagoryId" });
            DropTable("dbo.SuppliersProducts");
            DropTable("dbo.People");
            DropTable("dbo.Products");
            DropTable("dbo.Catagories");
        }
    }
}
