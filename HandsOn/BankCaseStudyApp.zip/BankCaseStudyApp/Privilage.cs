﻿namespace BankCaseStudyApp
{
    public enum Privilage
    {
        PREMIUM, GOLD, SILVER
    }
}
